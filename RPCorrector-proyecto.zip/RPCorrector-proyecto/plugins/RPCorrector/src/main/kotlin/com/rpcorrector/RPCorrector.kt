package com.rpcorrector

import android.content.Context
import android.content.res.Resources
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.AbsListView
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import com.aliucord.annotations.AliucordPlugin
import com.aliucord.entities.Plugin
import com.aliucord.patcher.after
import com.discord.widgets.chat.input.WidgetChatInput

@AliucordPlugin(requiresRestart = false)
@Suppress("unused")
class RPCorrector : Plugin() {
    private var button: TextView? = null
    private var lastOriginal: String? = null
    private val main = Handler(Looper.getMainLooper())

    override fun start(context: Context) {
        patcher.after<WidgetChatInput>("onViewBound", View::class.java) { param ->
            try {
                install(param.args[0] as View)
            } catch (t: Throwable) {
                logger.error("No se pudo instalar el botón de corrección", t)
            }
        }
    }

    override fun stop(context: Context) {
        patcher.unpatchAll()
        (button?.parent as? ViewGroup)?.removeView(button)
        button = null
    }

    // ---------------------------------------------------------------- UI

    private fun install(root: View) {
        val ctx = root.context
        val edit = findEdit(root) ?: return
        val send = findSend(root)

        val anchorForContainer = send ?: edit
        val container = pickContainer(anchorForContainer) ?: (root as? ViewGroup) ?: return

        // Evita duplicados si onViewBound se llama más de una vez.
        (button?.parent as? ViewGroup)?.removeView(button)

        val size = dp(ctx, 40)
        val btn = TextView(ctx).apply {
            text = "✨"
            textSize = 18f
            gravity = Gravity.CENTER
            contentDescription = "Corregir texto (mantén presionado para deshacer)"
            elevation = dp(ctx, 4).toFloat()
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.parseColor("#5865F2"))
            }
        }
        button = btn

        // Permitir que el botón se dibuje fuera de los límites de sus contenedores.
        var p: View? = anchorForContainer
        while (p != null) {
            (p as? ViewGroup)?.apply { clipChildren = false; clipToPadding = false }
            if (p === container) break
            p = p.parent as? View
        }

        container.addView(btn, ViewGroup.LayoutParams(size, size))

        val reposition = {
            if (btn.isAttachedToWindow) place(container, send, edit, btn)
        }
        container.viewTreeObserver.addOnGlobalLayoutListener {
            if (btn.isAttachedToWindow) reposition()
        }
        btn.post { reposition() }

        btn.setOnClickListener { runCorrection(ctx, edit, btn) }
        btn.setOnLongClickListener {
            val prev = lastOriginal
            if (prev == null) {
                toast(ctx, "No hay nada que deshacer")
            } else {
                edit.setText(prev)
                edit.setSelection(edit.text.length)
                lastOriginal = null
                toast(ctx, "Corrección deshecha")
            }
            true
        }
    }

    private fun place(container: ViewGroup, send: View?, edit: View, btn: View) {
        val anchor = if (send != null && send.isShown && send.width > 0) send else edit
        val a = IntArray(2)
        val c = IntArray(2)
        anchor.getLocationInWindow(a)
        container.getLocationInWindow(c)

        val margin = dp(btn.context, 6)
        val targetX =
            if (anchor === send) a[0] - c[0] + (anchor.width - btn.width) / 2f
            else a[0] - c[0] + anchor.width - btn.width - margin.toFloat()
        val targetY = a[1] - c[1] - btn.height - margin.toFloat()

        btn.translationX = targetX - btn.left
        btn.translationY = targetY - btn.top
    }

    private fun runCorrection(ctx: Context, edit: EditText, btn: TextView) {
        val original = edit.text?.toString().orEmpty()
        if (original.isBlank()) {
            toast(ctx, "Escribe algo primero")
            return
        }

        btn.isEnabled = false
        btn.alpha = 0.5f

        Thread {
            val result = try {
                Corrector.correct(original)
            } catch (t: Throwable) {
                Corrector.Result(original, "Error inesperado: ${t.message}")
            }
            main.post {
                btn.isEnabled = true
                btn.alpha = 1f
                if (result.text != original) {
                    lastOriginal = original
                    edit.setText(result.text)
                    edit.setSelection(edit.text.length)
                }
                when {
                    result.warning != null -> toast(ctx, result.warning)
                    result.text == original -> toast(ctx, "Todo se ve bien ✅")
                }
            }
        }.start()
    }

    // ---------------------------------------------------------------- Búsqueda de vistas

    private fun findEdit(v: View): EditText? {
        if (v is EditText) return v
        if (v is ViewGroup) {
            for (i in 0 until v.childCount) {
                findEdit(v.getChildAt(i))?.let { return it }
            }
        }
        return null
    }

    /** Busca la vista cuyo id contenga "send" (el botón de enviar de Discord). */
    private fun findSend(v: View): View? {
        if (v.id != View.NO_ID) {
            val name = try {
                v.resources.getResourceEntryName(v.id)
            } catch (e: Resources.NotFoundException) {
                null
            }
            if (name != null && name.contains("send", ignoreCase = true)) return v
        }
        if (v is ViewGroup) {
            for (i in 0 until v.childCount) {
                findSend(v.getChildAt(i))?.let { return it }
            }
        }
        return null
    }

    /** Un contenedor donde se pueda posicionar libremente (no LinearLayout ni listas). */
    private fun pickContainer(anchor: View): ViewGroup? {
        var p = anchor.parent as? ViewGroup
        while (p != null &&
            (p is LinearLayout || p is AbsListView || p.javaClass.name.contains("RecyclerView"))
        ) {
            p = p.parent as? ViewGroup
        }
        return p
    }

    private fun dp(ctx: Context, v: Int) = (v * ctx.resources.displayMetrics.density).toInt()

    private fun toast(ctx: Context, msg: String) =
        Toast.makeText(ctx, msg, Toast.LENGTH_LONG).show()
}
