package com.rpcorrector

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/**
 * Corrector de español basado en LanguageTool (API pública y gratuita, sin API key).
 * Límite aproximado del servicio gratuito: 20 peticiones por minuto.
 *
 * Flujo:
 *  1. Se envía el texto a LanguageTool marcando como "markup" (ignorado) las menciones,
 *     emojis personalizados, enlaces, bloques de código y los símbolos de formato de Discord
 *     (*, _, ~~, ||) para que tu rol en cursiva/negrita no se rompa.
 *  2. Se aplican las sugerencias (ortografía, comas, gramática, mayúsculas...).
 *  3. Un pulido local agrega ¿ ¡, mayúscula al inicio de cada oración, espacios correctos
 *     y la coma/espacio después de signos.
 */
object Corrector {
    private const val API = "https://api.languagetool.org/v2/check"

    data class Result(val text: String, val warning: String?)

    // Tokens que nunca se deben tocar (ni siquiera se envían como texto a revisar).
    private val PROTECTED_TEXT = Regex(
        """<a?:\w+:\d+>|<[@#][!&]?\d+>|https?://\S+|```[\s\S]*?```|`[^`\n]+`"""
    )

    // Protegidos + símbolos de formato de Discord.
    private val PROTECTED_ALL = Regex(
        """<a?:\w+:\d+>|<[@#][!&]?\d+>|https?://\S+|```[\s\S]*?```|`[^`\n]+`|\*+|__|_|~~|\|\|"""
    )

    private val SENTENCE = Regex("[^.!?…\n]+[.!?…]*|[.!?…\n]+")
    private val MASK_BACK = Regex("(\\d+)")

    fun correct(original: String): Result {
        var text = original
        var warning: String? = null

        try {
            text = remote(original)
        } catch (t: Throwable) {
            warning = when {
                t.message?.contains("429") == true -> "Demasiadas peticiones al servicio gratuito, espera un minuto. Apliqué solo el pulido local."
                else -> "No pude conectar con el corrector (${t.javaClass.simpleName}). Apliqué solo el pulido local."
            }
        }

        return Result(polish(text), warning)
    }

    // ---------------------------------------------------------------- LanguageTool

    private fun annotation(text: String): String {
        val arr = JSONArray()
        var last = 0
        for (m in PROTECTED_ALL.findAll(text)) {
            if (m.range.first > last) {
                arr.put(JSONObject().put("text", text.substring(last, m.range.first)))
            }
            val item = JSONObject().put("markup", m.value)
            when {
                m.value.startsWith("<@") || m.value.startsWith("<#") -> item.put("interpretAs", "Juan")
                m.value.startsWith("http") -> item.put("interpretAs", "enlace")
            }
            arr.put(item)
            last = m.range.last + 1
        }
        if (last < text.length) arr.put(JSONObject().put("text", text.substring(last)))
        return JSONObject().put("annotation", arr).toString()
    }

    private fun remote(text: String): String {
        val body = "language=es&level=picky&data=" +
                URLEncoder.encode(annotation(text), "UTF-8")

        val conn = URL(API).openConnection() as HttpURLConnection
        try {
            conn.requestMethod = "POST"
            conn.connectTimeout = 8000
            conn.readTimeout = 12000
            conn.doOutput = true
            conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded")
            conn.setRequestProperty("Accept", "application/json")
            conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }

            val code = conn.responseCode
            if (code != 200) throw RuntimeException("HTTP $code")

            val response = conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
            val matches = JSONObject(response).getJSONArray("matches")

            val list = (0 until matches.length())
                .map { matches.getJSONObject(it) }
                .sortedByDescending { it.getInt("offset") }

            val out = StringBuilder(text)
            var limit = Int.MAX_VALUE
            for (m in list) {
                val off = m.getInt("offset")
                val len = m.getInt("length")
                if (off + len > limit || off + len > out.length) continue // solapado
                val reps = m.getJSONArray("replacements")
                if (reps.length() == 0) continue
                val replacement = reps.getJSONObject(0).getString("value")
                out.replace(off, off + len, replacement)
                limit = off
            }
            return out.toString()
        } finally {
            conn.disconnect()
        }
    }

    // ---------------------------------------------------------------- Pulido local

    fun polish(input: String): String {
        val masks = ArrayList<String>()
        var s = PROTECTED_TEXT.replace(input) {
            masks.add(it.value)
            "${masks.size - 1}"
        }

        s = s.replace(Regex("[ \t]{2,}"), " ")          // espacios dobles
        s = s.replace(Regex("[ \t]+([,;:.!?…])"), "$1") // espacio antes de signos
        s = s.replace(Regex(",(?=\\p{L})"), ", ")       // espacio tras coma

        val sb = StringBuilder()
        for (m in SENTENCE.findAll(s)) sb.append(fixSentence(m.value))

        return MASK_BACK.replace(sb.toString()) { masks[it.groupValues[1].toInt()] }
    }

    private const val SKIP = " *_~\"'(«—-¿¡"

    private fun fixSentence(seg: String): String {
        var i = 0
        while (i < seg.length && seg[i] in SKIP) i++
        if (i >= seg.length) return seg

        val trimmed = seg.trimEnd()
        val open: Char? = when (trimmed.lastOrNull()) {
            '?' -> '¿'
            '!' -> '¡'
            else -> null
        }

        val sb = StringBuilder(seg)
        var pos = i
        if (open != null && !seg.contains(open)) {
            sb.insert(i, open)
            pos = i + 1
        }
        if (pos < sb.length && sb[pos].isLowerCase()) {
            sb.setCharAt(pos, sb[pos].uppercaseChar())
        }
        return sb.toString()
    }
}
