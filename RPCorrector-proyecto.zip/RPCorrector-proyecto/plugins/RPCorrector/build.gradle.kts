version = "1.0.0"
description = "Botón ✨ sobre Enviar que corrige ortografía, comas y signos (¿ ¡) de tus mensajes de rol en español."

aliucord {
    changelog.set(
        """
        # 1.0.0
        * Primera versión: botón de corrección con LanguageTool (gratis).
        * Mantén presionado el botón para deshacer la última corrección.
        """.trimIndent(),
    )

    // Plugin sin publicar en repositorios globales.
    deploy.set(false)
}
