# RPCorrector – plugin de Aliucord

Botón ✨ encima de **Enviar** que corrige ortografía, comas, mayúsculas y agrega los ¿ ¡ que falten.
Usa LanguageTool (gratis, sin API key). Mantén presionado el botón para deshacer.

> ⚠️ Este zip es el **código fuente**. NO lo pongas en la carpeta de plugins de Aliucord
> (por eso salía "No manifest found"). Primero hay que **compilarlo**; el resultado es
> `RPCorrector.zip`, que sí trae el manifest.

## Opción A – Compilar gratis con GitHub (sin PC)

1. Crea una cuenta en github.com y un repositorio nuevo (privado o público).
2. Sube TODO el contenido de esta carpeta al repositorio (incluida la carpeta oculta `.github`).
3. Antes, abre `plugins/build.gradle.kts` y cambia `author("TuNombre", ...)` por tu nombre.
4. En el repositorio ve a **Actions → Build → Run workflow** (se ejecuta solo al subir archivos).
5. Cuando termine (unos minutos), entra a la ejecución y descarga el artefacto **RPCorrector**.
   Dentro hay `RPCorrector.zip`.
6. Copia ese `RPCorrector.zip` a `Almacenamiento/Aliucord/plugins/` y reinicia Aliucord.

## Opción B – Compilar en tu PC

Necesitas JDK 21 y el Android SDK (lo más fácil es abrir esta carpeta con Android Studio).

```
./gradlew :RPCorrector:make
```

El plugin queda en `plugins/RPCorrector/build/outputs/RPCorrector.zip`.
Con el teléfono conectado por adb: `./gradlew :RPCorrector:deployWithAdb`.

## Notas

- Servicio gratuito: ~20 revisiones por minuto. Si te pasas, avisa y aplica solo el pulido local.
- Respeta `*acciones*`, cursivas, negritas, spoilers, menciones, emojis y enlaces.
- Si el botón queda mal ubicado tras una actualización de Discord, ajusta `findSend()` y `place()`
  en `plugins/RPCorrector/src/main/kotlin/com/rpcorrector/RPCorrector.kt`.
